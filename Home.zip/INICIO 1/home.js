let currentSlide = 0;
const slides = document.querySelectorAll(".news-item");

// Inicializar mostrando solo el primer slide
slides[currentSlide].classList.add("active");

document.getElementById("next").addEventListener("click", () => {
    changeSlide(1);
});

document.getElementById("prev").addEventListener("click", () => {
    changeSlide(-1);
});

function changeSlide(direction) {
    slides[currentSlide].classList.remove("active");
    currentSlide = (currentSlide + direction + slides.length) % slides.length;
    slides[currentSlide].classList.add("active");
}

